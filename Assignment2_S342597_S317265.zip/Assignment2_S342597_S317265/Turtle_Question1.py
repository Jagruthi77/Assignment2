import turtle
from turtle import*
import random
t=Turtle()
#t.shape("turtle")
#t.color("red")
t.pensize(5)
wn=turtle.Screen()
wn.bgcolor("#AAAAFF")
for i in range(100):
    turtle.color("red")
    turtle.shape("turtle")
    turtle.circle(5*i)
    turtle.color("green")
    turtle.circle(-5*i)
    turtle.left(i)
turtle.exitonclick()
