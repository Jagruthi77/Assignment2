import tkinter
from PIL import ImageTk
from PIL import Image
import random
# top-level widget which represents the main window 
root = tkinter.Tk()
root.geometry('400x400')
root.iconbitmap('icon.ico')
root.configure(background='light green')
root.title('Roll the Dice')


# Adding label into the frame
BlankLine = tkinter.Label(root, text="")
BlankLine.pack()

# adding label with different font and formatting
HeadingLabel = tkinter.Label(root, text="Dice Game!",
   fg = "light green",
     bg = "dark green",
     font = "Helvetica 16 bold italic")
HeadingLabel.pack()

# images
dice = ['die1.png', 'die2.png', 'die3.png', 
    'die4.png', 'die5.png', 'die6.png']
# simulating the dice with random numbers between
# 0 to 6 and generating image
DiceImage = ImageTk.PhotoImage(Image.open(random.choice(dice)))

# construct a label widget for image
ImageLabel = tkinter.Label(root, image=DiceImage)
ImageLabel.image = DiceImage

# packing a widget in the parent widget 
ImageLabel.pack( expand=True)

# function activated by button
def rolling_dice():
    DiceImage = ImageTk.PhotoImage(Image.open(random.choice(dice)))
    # update image
    ImageLabel.configure(image=DiceImage)
    # keep a reference
    ImageLabel.image = DiceImage

# adding button, and command will use rolling_dice function
button = tkinter.Button(root, text='PLAYER1 Roll the Dice', fg='blue', command=rolling_dice)

# pack a widget in the parent widget
button.pack( expand=True)


#Second dice
# images
dice1 = ['die1.png', 'die2.png', 'die3.png', 
    'die4.png', 'die5.png', 'die6.png']
# dice with random numbers between 0 to 6 and generating image
DiceImage1 = ImageTk.PhotoImage(Image.open(random.choice(dice)))

# construct a label widget for image
ImageLabel1 = tkinter.Label(root, image=DiceImage1)
ImageLabel1.image = DiceImage1

# packing a widget in the parent widget 
ImageLabel1.pack( expand=True)

# On button click this function is called or executed
def rolling_dice1():
    DiceImage1 = ImageTk.PhotoImage(Image.open(random.choice(dice1)))
    # update image
    ImageLabel1.configure(image=DiceImage1)
    # keeping a reference
    ImageLabel1.image = DiceImage1

# adding button, and command will use rolling_dice1 function
button1 = tkinter.Button(root, text='PLAYER2 Roll the Dice', fg='blue', command=rolling_dice1)

# pack a widget in the parent widget
button1.pack(expand=True)

# call the mainloop of Tk
# keeps window open
root.mainloop()